Google CSE
==========

Plugin for adding a Google Custom Search Engine

The plugin works with themes with a sidebar.

To use the plugin you need a Google account and a search engine ID. You can optain an ID at https://cse.google.com.

At the moment the plugin works only with http:// (not SSL certificates with https://).

To show the search button please choose in "Look and feel" > "Design" a theme except the theme "Default".

For further explanation and configuration see https://cse.google.com.

Versions
--------

Version 0.1, 4. December 2015
