This version of SimpleMDE have a little changes for Bludit.

--- Image preview hack ---

Original
<img src="'+e+'"

Bludit hack
<img src="'+HTML_PATH_UPLOADS+e+'"