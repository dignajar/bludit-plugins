editArea.add_lang("de",{
test_select: "Tag ausw&auml;hlen",
test_but: "Test Button"
});
