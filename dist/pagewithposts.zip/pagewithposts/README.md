Page with Posts
===============

Plugin to use a page to show posts.

Versions
--------

*Version 0.2, December 30, 2015*

Fix for installations in a subdirecory.

*Version 0.1, December 28, 2015*
