Tag as title
============

The plugin adds the tag as title.

Versions
--------

1.0, January 29, 2017
- Release.
