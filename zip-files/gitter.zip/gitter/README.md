Gitter
==========

This plugin is a (mostly) code-free way of embedding Gitter into your website with a simple JavaScript snippet.

It works out of the box with no customization, or you can control its behaviour with some basic configuration.

Versions
--------

0.2, August 23, 2016
- Added README and metadata.json;
- Plugin code cleaned.

0.1, November 15, 2015
- Release.
