CKEditor with RESPONSIVE Filemanger 
===================================

Versions
--------

1.6.1, May 14, 2017
- Fix of lost path fixes.

1.6., March 4, 2017
- Update from CKEditor 4.5.7 to 4.6.2.
- Update from RESPONSIVE Filemanager 9.10.1 to 9.11.0.
- Fix of path in filemanager/config/config.php.
