Textarea
==========

Textarea allows to show text in the sidebar using HTML code.

The plugin is a modification of the plugin About.

Versions
--------

1.0, August 10, 2016
- Release.
