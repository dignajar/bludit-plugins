Simple CSS Menu
===============

Simple accordion menu with CSS using code by @yorozuna (http://codepen.io/yorozuna/).

Versions
--------

0.2, February 24, 2016
- Active link for parents.

0.1, February 13, 2016
- Release.
