# bludit-isso-client

This is a plugin for the [bludit CMS](https://www.bludit.com/) to use your [isso comment server](https://posativ.org/isso/) with it.

It provides a CLIENT for isso - it DOES NOT install a isso server! You have to provide it separately.

If you want to know more about the configuration of this plugin, see the [dedicated part of the isso documentation](https://posativ.org/isso/docs/configuration/client/).


*** NOTE: This plugin is still in it's early stages. So be kind and post an issue, if you encounter anything strange. ***
