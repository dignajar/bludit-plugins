Custom Image Dimensions
==========

This plugin uses jQuery to allow you to set custom dimensions for your images directly on markdown.

To set image dimensions you just use: `![Test image heigh=X width=Y](http://link.to/your_image)`.

Where X and Y should be any value in pixels (% values will not work).

Versions
--------

0.1, August 24, 2016
- Release.
