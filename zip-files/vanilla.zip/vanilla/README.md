Vanilla Forums
==============

Integration of Vanilla Forums as comment system.

More information about the open source community forum software at https://open.vanillaforums.com.

At the moment the plugin works only with posts.


Versions
--------

1.1, June 4, 2017
- Fiexed: Display of comment field only on pages with single post.

1.0, January 16, 2017
- Release.
