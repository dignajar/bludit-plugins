Vanilla Forums
==============

Integration of Vanilla Forums as comment system.

More information about the open source community forum software at https://open.vanillaforums.com.

At the moment the plugin works only with posts.


Versions
--------

1.0, January 16, 2015
- Release.
