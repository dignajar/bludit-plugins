## AddToAny for Bludit
### AddToAny Social Sharing Buttons

**Add social sharing buttons to your posts and pages.**

A simple little plugin which allows your readers to share your posts on over 50 social networks.

You can view a demo of this plugin at [320up.com](https://320up.com/demo/bludit/)
