Custom CSS
==========

Add custom CSS to a theme.

Uses the CodeMirror editor (https://codemirror.net/).

Versions
--------

0.4, June 20, 2016
- Addition of the field "compatible" (since v1.4).

0.3, January 27, 2016
- Update for v1.0.1.

0.2, January 12, 2016
- Implementation of CodeMirror editor.

0.1, January 5, 2016
- Release.
